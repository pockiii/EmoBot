public class Scanner {
	
}
